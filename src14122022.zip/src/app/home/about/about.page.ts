import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-about',
  templateUrl: './about.page.html',
  styleUrls: ['./about.page.scss'],
})
export class AboutPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }
  public bgaeman = "../../../assets/img/bg-about.jpg";
  public user = "Aeman105";
  public quoteaeman = " GNU GENERAL PUBLIC LICENSE Version 3. Read the license?";

  public aeman = [
    { accIMG: "../../../assets/img/github.png",
      acc: "Github : Aeman105",
      imgURL: "github-acc.png",
      accName: "Aeman105",
      desc: "This is a new account separated from my school work. Thus its recent creation",
      accURL: "https://github.com/Aeman105",
      logo: "logo-github"
    },
    {
      accIMG: "../../../assets/img/telegram.jpg",
      acc: "Telegram Channel: Android4/5 Apps List",
      imgURL: "telegram.jpg",
      accName: "@Android4_5List_Chat",
      desc: "",
      accURL: "https://t.me/Android4_5List_Chat",
      logo: "paper-plane"
    },
    {
      accIMG: "../../../assets/img/telegram.jpg",
      acc: "Telegram Channel: ReaL (ResourceLinker)",
      imgURL: "telegram.jpg",
      accName: "@RL_ResourceLinkerApp",
      desc: "All about this app called ReaL, weird as it sounds. https://github.com/Aeman105/vmos_resources/releases",
      accURL: "https://t.me/RL_ResourceLinkerApp",
      logo: "paper-plane"
    },
    {
      accIMG: "../../../assets/img/telegram.jpg",
      acc: "Telegram Channel: Aeman M",
      imgURL: "telegram-aeman-m1.jpg",
      accName: "@Aeman105Gamer",
      desc: "Aeman105Gamer's projects, interests, arts. Took a course in Web Development. I'm sorry for being so random. I'm just another noob, and a stingy person.",
      accURL: "https://t.me/Aeman105Gamer",
      logo: "paper-plane"
    },
    {
      accIMG: "../../../assets/img/twitter.png",
      acc: "Twitter: Code:05",
      imgURL: "twitter-aeman.jpg",
      accName: "@Code0531798776",
      desc: "Im eccentric.",
      accURL: "https://mobile.twitter.com/Code0531798776",
      logo: "logo-twitter"
    },
    {
      accIMG: "../../../assets/img/reddit.png",
      acc: "Reddit: Aeman105Gamer",
      imgURL: "reddit-aeman105gamer.png",
      accName: "u/Aeman105Gamer",
      desc: "I write and reply to the other redditors, only to remind and help myself. In reality, nobody is pure and good. Also known as Norhazman Aeman. (am not a robot)",
      accURL: "https://www.reddit.com/user/Aeman105Gamer",
      logo: "logo-reddit"
    },
    {
      accIMG: "../../assets/img/4pda.png",
      acc: "4pda",
      imgURL: "bg-about.jpg",
      accName: "No account",
      desc: "Mentioned in 4pda",
      accURL: "https://4pda.to/forum/index.php?forums=317&topics=961828&act=search&source=pst&query=Aeman",
      logo: "chatbubble"
    },
    {
      accIMG: "../../assets/icon/favicon.png",
      acc: "Spotify",
      imgURL: "spotify-aeman105.jpg",
      accName: "Spotify Account",
      desc: "My public Spotify playlist",
      accURL: "https://open.spotify.com/user/317o2ytdy65fesgk5sxaozbetzfq?si=10d08966f7e44f3b",
      logo: ""
    },
  ]

}

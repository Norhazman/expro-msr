export class aeman {
  constructor(public accIMG: string,
              public acc: string,
              public imgURL: string,
              public accName: string,
              public desc: string,
              public accURL: string,
              public logo: string
              ){}
}

import { Component } from '@angular/core';
import { Router } from '@angular/router';
// import { AuthService } from './services/auth.service';

@Component({
  selector: 'app-root',
  templateUrl: 'app.component.html',
  styleUrls: ['app.component.scss'],
})
export class AppComponent {

  public appPages = [
    { title: 'Home', url: '/home', icon: 'home' },
  ];

  // public appPages2 = [
  //   { title: 'Tips', url: '/tips', icon: 'briefcase' },
  //   { title: 'Help', url: '/help', icon: 'bandage' },
  //   { title: 'About', url: '/home/about', icon: 'image'},
  // ];

  // public appPages3 = [
  //   { title: 'Onboarding', url: '/onboarding', icon: 'nuclear' },
  // ];

  // public vmosrommodPages = [
  //   { title: 'HuskyDG', url: '/husky-dg', icon: 'balloon', img: '../../assets/img/bg-husky-dg.jpg' },
  // ];

  // public twoyiPages = [
  //   { title: 'TWOYI Apps', url: '/twoyi-apps', icon: 'nuclear' },
  //   { title: 'Weishu', url: '/weishu', icon: 'logo-android' },
  // ];

  constructor(
              private router: Router
              ) {}

    onList() {
      let buttons=0;
    }
}

/* eslint-disable max-len */
import { Injectable } from '@angular/core';
import { AuthService } from '../auth/auth.service';
import { Place } from './place.model';
import { BehaviorSubject } from 'rxjs';
import { take, map, tap, delay } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class PlacesService {

  private places = new BehaviorSubject<Place[]>( [
    // new Place('p1', 'Empire Hotel', '5 star hotel, Very nice.', 'https://upload.wikimedia.org/wikipedia/en/c/ca/742_Evergreen_Terrace.png', 350, new Date('2019-01-01'), new Date('2022-12-31'), 'abc123'),
    // new Place('p2', 'Simpsons House', 'Somewhere in Springfield, Forever lost.', 'https://upload.wikimedia.org/wikipedia/en/c/ca/742_Evergreen_Terrace.png', 50, new Date('2022-01-01'), new Date('2022-12-31'), 'abc123'),
    // new Place('p3', 'Castle of Narnia', 'Hidden behind the wardrobe.', 'https://upload.wikimedia.org/wikipedia/en/c/ca/742_Evergreen_Terrace.png', 100.99, new Date('2022-03-01'), new Date('2022-12-31'), 'abc12')
  ]);

  constructor(private authService: AuthService) { }

  get $places() {
    return this.places.asObservable();
  }

  getPlace(id: string) {
    return this.$places.pipe(take(1), map(places => {
      return {...places.find(p => p.id === id)};
    }));
  }

  addPlace(title: string,
            description: string,
            price: number,
            dateFrom: Date,
            dateTo: Date) {
              const newPlace = new Place(Math.random().toString(),
                title,
                description,
                'https://upload.wikimedia.org/wikipedia/en/c/ca/742_Evergreen_Terrace.png',
                price,
                dateFrom,
                dateTo,
                this.authService.$userId
              );
              return this.$places.pipe(take(1), delay(1000), tap(places => {
                this.places.next(places.concat(newPlace));
              }));
            }

            updateOffer(placeId: string,
                        title: string,
                        description: string){
                          return this.$places.pipe(take(1), tap(places => {
                            const upadatedPlaceIndex = places.findIndex(pl => pl.id === placeId);
                            const updatedPlaces = [...places];
                            const oldPlace = updatedPlaces[upadatedPlaceIndex];
                            updatedPlaces[upadatedPlaceIndex] = new Place(
                              oldPlace.id,
                              title,
                              description,
                              oldPlace.imageUrl,
                              oldPlace.price,
                              oldPlace.availableFrom,
                              oldPlace.availableTo,
                              oldPlace.userId);
                              this.places.next(updatedPlaces);
                          }));
            }
}

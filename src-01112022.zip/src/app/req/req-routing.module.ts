import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { ReqPage } from './req.page';

const routes: Routes = [
  {
    path: 'tabs',
    component: ReqPage,
    children: [
      {
        path: 'it',
        loadChildren: () => import('./it/it.module').then( m => m.ItPageModule)
      },
      {
        path: 'pantry',
        loadChildren: () => import('./pantry/pantry.module').then( m => m.PantryPageModule)
      },
      {
        path: '',
        redirectTo: '/req',
        pathMatch: 'full'
      }
    ]
  },
  {
    path: '',
    redirectTo: '/req',
    pathMatch: 'full'
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class ReqPageRoutingModule {}

import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pantry',
  templateUrl: './pantry.page.html',
  styleUrls: ['./pantry.page.scss'],
})
export class PantryPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

  public pantry = [
    {
      itemIMG: "../../../assets/img/staplers.jpg",
      itemName: "Coffee bean Lavazza",
    },
    {
      itemIMG: "../../../assets/img/staplers.jpg",
      itemName: "Sugar pack - 3 bags",
    },
    {
      itemIMG: "../../../assets/img/staplers.jpg",
      itemName: "Milk - 1 Litre",
    },
    {
      itemIMG: "../../../assets/img/staplers.jpg",
      itemName: "Chocomalt milk",
    },
    {
      itemIMG: "../../../assets/img/staplers.jpg",
      itemName: "Jacob Biscuit Watermeal",
    },
    {
      itemIMG: "../../../assets/img/staplers.jpg",
      itemName: "Danisa Butter Cookie",
    },
    {
      itemIMG: "../../../assets/img/staplers.jpg",
      itemName: "Maggie Curry cup",
    },
    {
      itemIMG: "../../../assets/img/staplers.jpg",
      itemName: "Maggie Tom Yum cup",
    },
    {
      itemIMG: "../../../assets/img/staplers.jpg",
      itemName: "Milo - 5 Tins",
    },
    {
      itemIMG: "../../../assets/img/staplers.jpg",
      itemName: "Tea packs",
    },
    {
      itemIMG: "../../../assets/img/staplers.jpg",
      itemName: "Vinda Toilet Tissue",
    },
    {
      itemIMG: "../../../assets/img/staplers.jpg",
      itemName: "Vinda Multipurpose disinfection wipe",
    },
    {
      itemIMG: "../../../assets/img/staplers.jpg",
      itemName: "Kleenex Tissue box",
    },
    {
      itemIMG: "../../../assets/img/staplers.jpg",
      itemName: "Jura milk tube & hose connector or milk Pipe with stainless steel casing HP3 part number: 24114",
    },
    {
      itemIMG: "../../../assets/img/staplers.jpg",
      itemName: "Jura glass milk container 16.07 OZ Part Number 72570",
    },
    {
      itemIMG: "../../../assets/img/staplers.jpg",
      itemName: "Water tank filter - claris smart",
    },
    {
      itemIMG: "../../../assets/img/staplers.jpg",
      itemName: "Milk system cleaner",
    },
    {
      itemIMG: "../../../assets/img/staplers.jpg",
      itemName: "Jura Cleaning tablets",
    },
    {
      itemIMG: "../../../assets/img/staplers.jpg",
      itemName: "Jura Descaling Tablets",
    },
    {
      itemIMG: "../../../assets/img/staplers.jpg",
      itemName: "Julie Peanut - 10 boxes",
    },
    {
      itemIMG: "../../../assets/img/staplers.jpg",
      itemName: "Mix Biscuit - 10 tins",
    },
    {
      itemIMG: "../../../assets/img/staplers.jpg",
      itemName: "Lexus Munchy's Biscuits - 10 packs",
    },
    {
      itemIMG: "../../../assets/img/staplers.jpg",
      itemName: "Fresh Milk Brand Paul 1 Litre 12s - 3 boxes",
    },
    {
      itemIMG: "../../../assets/img/staplers.jpg",
      itemName: "Dettol Hands Wash Liquid 250ml",
    },
    {
      itemIMG: "../../../assets/img/staplers.jpg",
      itemName: "Glo (Soft Touch) Big bottle - 10 bottle",
    },
    {
      itemIMG: "../../../assets/img/staplers.jpg",
      itemName: "Kitchen Scott Tissue 6s - 5pkts",
    },
    {
      itemIMG: "../../../assets/img/staplers.jpg",
      itemName: "Kleenex Face Tissue 5s - 5 pkts",
    },
    {
      itemIMG: "../../../assets/img/staplers.jpg",
      itemName: "Toilet Tissue - 5 pkts",
    },
    {
      itemIMG: "../../../assets/img/staplers.jpg",
      itemName: "Daia Floor Cleaner 2L - 10 btl",
    },
    {
      itemIMG: "../../../assets/img/staplers.jpg",
      itemName: "CIF Cream (big) - 10 btl",
    },
    {
      itemIMG: "../../../assets/img/staplers.jpg",
      itemName: "Harpic 500 ml - 10 btl",
    },
    {
      itemIMG: "../../../assets/img/staplers.jpg",
      itemName: "Lix Floor Cleaner - 10 btl",
    },
    {
      itemIMG: "../../../assets/img/staplers.jpg",
      itemName: "Shieldtox Odorless 600ml - 2btl",
    },
    {
      itemIMG: "../../../assets/img/staplers.jpg",
      itemName: "Breeze Powder - 5 bags",
    },
    {
      itemIMG: "../../../assets/img/staplers.jpg",
      itemName: "Febreze Perfume 250ml - 10btl (Air)",
    },
    {
      itemIMG: "../../../assets/img/staplers.jpg",
      itemName: "Wipe (blue bottle) - 10btl",
    },
    {
      itemIMG: "../../../assets/img/staplers.jpg",
      itemName: "Garbage Bag Big 76cm x 99cm - 30 pkts",
    },
    {
      itemIMG: "../../../assets/img/staplers.jpg",
      itemName: "Garbage Bag Small 20 x 24 100s - 30 pkts",
    },
    {
      itemIMG: "../../../assets/img/staplers.jpg",
      itemName: "Horlicks - 5 tins",
    },
  ]

}

export class pantry {
  constructor(public itemIMG: string,
              public itemName: string,
              // public desc: string,
              // public logo: string
              ){}
}

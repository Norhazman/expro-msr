import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-it',
  templateUrl: './it.page.html',
  styleUrls: ['./it.page.scss'],
})
export class ItPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

  public it = [
    {
      itemIMG: "../../../assets/img/staplers.jpg",
      itemName: "HDMI Type A (Standard HDMI) cable",
    },
    {
      itemIMG: "../../../assets/img/staplers.jpg",
      itemName: "VGA cable",
    },
    {
      itemIMG: "../../../assets/img/staplers.jpg",
      itemName: "Cable Adapter Converter HDMI to VGA",
    },
    {
      itemIMG: "../../../assets/img/staplers.jpg",
      itemName: "VGA Extender Male To LAN CAT5",
    },
    {
      itemIMG: "../../../assets/img/staplers.jpg",
      itemName: "Yarmit YCU891 wireless microphone",
    },
    {
      itemIMG: "../../../assets/img/staplers.jpg",
      itemName: "Standard Power Outlet Independent Switch Power Strip",
    },
    {
      itemIMG: "../../../assets/img/staplers.jpg",
      itemName: "Extension 4 Ports USB 3.0 Hub",
    },
    {
      itemIMG: "../../../assets/img/staplers.jpg",
      itemName: "Mouse pad",
    },
  ]
}

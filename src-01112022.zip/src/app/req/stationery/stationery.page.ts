import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-stationery',
  templateUrl: './stationery.page.html',
  styleUrls: ['./stationery.page.scss'],
})
export class StationeryPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

  public stationery = [
    {
      itemIMG: "../../../assets/img/staplers.jpg",
      itemName: "Staplers Bullet HD-10",
    },
    {
      itemIMG: "../../../assets/img/staplers.jpg",
      itemName: "Staplers Bullet HD-50R",
    },
    {
      itemIMG: "../../../assets/img/staplers.jpg",
      itemName: "Staple HD-10",
    },
    {
      itemIMG: "../../../assets/img/staplers.jpg",
      itemName: "Staple HD-50R",
    },
    {
      itemIMG: "../../../assets/img/staplers.jpg",
      itemName: "Puncher 2 Hole",
    },
    {
      itemIMG: "../../../assets/img/staplers.jpg",
      itemName: "Scissors",
    },
    {
      itemIMG: "../../../assets/img/staplers.jpg",
      itemName: "Metal Pen Holder",
    },
    {
      itemIMG: "../../../assets/img/staplers.jpg",
      itemName: "Paper Clip - Oval 2Inch",
    },
    {
      itemIMG: "../../../assets/img/staplers.jpg",
      itemName: "Paper Clip - Triangular",
    },
    {
      itemIMG: "../../../assets/img/staplers.jpg",
      itemName: "Whiteboard marker - Blue",
    },
    {
      itemIMG: "../../../assets/img/staplers.jpg",
      itemName: "Whiteboard marker - Red",
    },
    {
      itemIMG: "../../../assets/img/staplers.jpg",
      itemName: "Whiteboard marker - Green",
    },
    {
      itemIMG: "../../../assets/img/staplers.jpg",
      itemName: "Whiteboard marker - Black",
    },
    {
      itemIMG: "../../../assets/img/staplers.jpg",
      itemName: "Correction tape - Fluid",
    },
    {
      itemIMG: "../../../assets/img/staplers.jpg",
      itemName: "Correction tape - Paper/Roller",
    },
    {
      itemIMG: "../../../assets/img/staplers.jpg",
      itemName: "3 Tier Paper Tray",
    },
    {
      itemIMG: "../../../assets/img/staplers.jpg",
      itemName: "Highlighter - Blue",
    },
    {
      itemIMG: "../../../assets/img/staplers.jpg",
      itemName: "Highlighter - yellow",
    },
    {
      itemIMG: "../../../assets/img/staplers.jpg",
      itemName: "Highlighter - Green",
    },
    {
      itemIMG: "../../../assets/img/staplers.jpg",
      itemName: "Highlighter - Orange",
    },
    {
      itemIMG: "../../../assets/img/staplers.jpg",
      itemName: "Ballpoint pens - Blue 0.5",
    },
    {
      itemIMG: "../../../assets/img/staplers.jpg",
      itemName: "Ballpoint pens - Black 0.5",
    },
    {
      itemIMG: "../../../assets/img/staplers.jpg",
      itemName: "Ballpoint pens - Red 0.5",
    },
    {
      itemIMG: "../../../assets/img/staplers.jpg",
      itemName: "Blu-tack",
    },
    {
      itemIMG: "../../../assets/img/staplers.jpg",
      itemName: "Glue tape",
    },
    {
      itemIMG: "../../../assets/img/staplers.jpg",
      itemName: "UHU Glue Stick",
    },
    {
      itemIMG: "../../../assets/img/staplers.jpg",
      itemName: "Calculator Medium Size",
    },
    {
      itemIMG: "../../../assets/img/staplers.jpg",
      itemName: "Desktop Tape Dispenser",
    },
    {
      itemIMG: "../../../assets/img/staplers.jpg",
      itemName: "Cellotape for Tape Dispenser",
    },
    {
      itemIMG: "../../../assets/img/staplers.jpg",
      itemName: "Permanent marker - Thick",
    },
    {
      itemIMG: "../../../assets/img/staplers.jpg",
      itemName: "Permanent marker - Thin",
    },
    {
      itemIMG: "../../../assets/img/staplers.jpg",
      itemName: "Eraser",
    },
    {
      itemIMG: "../../../assets/img/staplers.jpg",
      itemName: "Mechanical pencil and Pencil leads 0.5",
    },
    {
      itemIMG: "../../../assets/img/staplers.jpg",
      itemName: "Mechanical pencil and Pencil leads 0.7",
    },
    {
      itemIMG: "../../../assets/img/staplers.jpg",
      itemName: "Plastic Ruler Long  30cm",
    },
    {
      itemIMG: "../../../assets/img/staplers.jpg",
      itemName: "Plastic Ruler Short 12cm",
    },
    {
      itemIMG: "../../../assets/img/staplers.jpg",
      itemName: "Metal Ruler Long 30cm",
    },
    {
      itemIMG: "../../../assets/img/staplers.jpg",
      itemName: "A4 Plastic pockets",
    },
    {
      itemIMG: "../../../assets/img/staplers.jpg",
      itemName: "Arch folder 3Inch - 2 Ring",
    },
    {
      itemIMG: "../../../assets/img/staplers.jpg",
      itemName: "Arch folder (White) - 3 Ring",
    },
    {
      itemIMG: "../../../assets/img/staplers.jpg",
      itemName: "Arch folder (White) - 4 Ring",
    },
    {
      itemIMG: "../../../assets/img/staplers.jpg",
      itemName: "Folder divider - Colourful",
    },
    {
      itemIMG: "../../../assets/img/staplers.jpg",
      itemName: "Sticky labels",
    },
    {
      itemIMG: "../../../assets/img/staplers.jpg",
      itemName: "Sticky notes 3x3",
    },
    {
      itemIMG: "../../../assets/img/staplers.jpg",
      itemName: "Sticky notes 3x5",
    },
    {
      itemIMG: "../../../assets/img/staplers.jpg",
      itemName: "Ring binder 10mm",
    },
    {
      itemIMG: "../../../assets/img/staplers.jpg",
      itemName: "Ring binder 12mm",
    },
    {
      itemIMG: "../../../assets/img/staplers.jpg",
      itemName: "Ring binder 14mm",
    },
    {
      itemIMG: "../../../assets/img/staplers.jpg",
      itemName: "USB Memory Sticks - 16GB",
    },
    {
      itemIMG: "../../../assets/img/staplers.jpg",
      itemName: "Batteries AA Size",
    },
    {
      itemIMG: "../../../assets/img/staplers.jpg",
      itemName: "Batteries AAA Size",
    },
    {
      itemIMG: "../../../assets/img/staplers.jpg",
      itemName: "White Board 4x4ft",
    },
    {
      itemIMG: "../../../assets/img/staplers.jpg",
      itemName: "White Board 4x5ft",
    },
    {
      itemIMG: "../../../assets/img/staplers.jpg",
      itemName: "White Board 4x6ft",
    },
    {
      itemIMG: "../../../assets/img/staplers.jpg",
      itemName: "White Board 4x8ft",
    },
    {
      itemIMG: "../../../assets/img/staplers.jpg",
      itemName: "Whiteboard eraser",
    },
    {
      itemIMG: "../../../assets/img/staplers.jpg",
      itemName: "Cleaning Spray for white board",
    },
    {
      itemIMG: "../../../assets/img/staplers.jpg",
      itemName: "Binder Clip 1 Inch",
    },
    {
      itemIMG: "../../../assets/img/staplers.jpg",
      itemName: "Binder Clip 1.3 Inch",
    },
    {
      itemIMG: "../../../assets/img/staplers.jpg",
      itemName: "Binder Clip 2 Inch",
    },
    {
      itemIMG: "../../../assets/img/staplers.jpg",
      itemName: "Notice Board Pin - Colourful",
    },
    {
      itemIMG: "../../../assets/img/staplers.jpg",
      itemName: "Extension wire - 4GANG 2 METER",
    },
    {
      itemIMG: "../../../assets/img/staplers.jpg",
      itemName: "Paper tape 1Inch",
    },
    {
      itemIMG: "../../../assets/img/staplers.jpg",
      itemName: "Paper tape 2Inch",
    },
    {
      itemIMG: "../../../assets/img/staplers.jpg",
      itemName: "Paper tape 3Inch",
    },
    {
      itemIMG: "../../../assets/img/staplers.jpg",
      itemName: "Double Sided Tape - Foam",
    },
    {
      itemIMG: "../../../assets/img/staplers.jpg",
      itemName: "Suspension tie",
    },
    {
      itemIMG: "../../../assets/img/staplers.jpg",
      itemName: "Paper Fastener",
    },
    {
      itemIMG: "../../../assets/img/staplers.jpg",
      itemName: "Hand held Sticker Label Printer",
    },
    {
      itemIMG: "../../../assets/img/staplers.jpg",
      itemName: "Magnetic pin for whiteboard",
    },
    {
      itemIMG: "../../../assets/img/staplers.jpg",
      itemName: "Sticker post-it labels",
    },


  ]

}

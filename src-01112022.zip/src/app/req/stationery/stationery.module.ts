import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { StationeryPageRoutingModule } from './stationery-routing.module';

import { StationeryPage } from './stationery.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    StationeryPageRoutingModule
  ],
  declarations: [StationeryPage]
})
export class StationeryPageModule {}

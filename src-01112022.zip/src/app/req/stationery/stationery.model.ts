export class stationery {
  constructor(public itemIMG: string,
              public itemName: string,
              // public desc: string,
              // public logo: string
              ){}
}

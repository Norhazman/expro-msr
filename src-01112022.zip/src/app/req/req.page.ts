import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-req',
  templateUrl: './req.page.html',
  styleUrls: ['./req.page.scss'],
})
export class ReqPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { AzmanPage } from './azman.page';

const routes: Routes = [
  {
    path: '',
    component: AzmanPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class AzmanPageRoutingModule {}

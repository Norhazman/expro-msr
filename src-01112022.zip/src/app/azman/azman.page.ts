import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-azman',
  templateUrl: './azman.page.html',
  styleUrls: ['./azman.page.scss'],
})
export class AzmanPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

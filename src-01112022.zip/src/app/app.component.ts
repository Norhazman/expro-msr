import { Component } from '@angular/core';
import { Router } from '@angular/router';
// import { AuthService } from './services/auth.service';

@Component({
  selector: 'app-root',
  templateUrl: 'app.component.html',
  styleUrls: ['app.component.scss'],
})
export class AppComponent {

  public appPages = [
    { title: 'Home', url: '/home', icon: 'home' },
  ];

  public appPages2 = [
    { title: 'Request list', url: '/req', icon: 'bandage' },
    { title: 'About', url: '/about', icon: 'image'},
    { title: 'Work of Aeman105', url: '/azman', icon: 'pulse'},
  ];

  public reqPages = [
    { title: 'Stationery items request', url: '/req/stationery', icon: 'nuclear' },
    { title: 'Pantry items request', url: '/req/pantry', icon: 'newspaper' },
    { title: 'IT items request', url: '/req/it', icon: 'book' },
  ];

  constructor(
    // private authService: AuthService,
              private router: Router
              ) {}

    onList() {
      let buttons=0;
    }

  // onLogout(){
  //   // this.authService.logout();
  //   this.router.navigateByUrl('/login');
  // }
}

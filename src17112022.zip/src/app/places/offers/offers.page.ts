import { Component, OnDestroy, OnInit } from '@angular/core';
import { IonItemSliding, Platform } from '@ionic/angular';
import { Place } from '../place.model';
import { PlacesService } from '../places.service';
import { Subscription } from 'rxjs';
import * as html2pdf from 'html2pdf.js';
import JSPDF from 'jspdf';
import domtoimage from 'dom-to-image';
import { FileOpener } from '@ionic-native/file-opener/ngx';
import { File, IWriteOptions } from '@ionic-native/file/ngx';

import pdfMake from "pdfmake/build/pdfmake";
import pdfFonts from "pdfmake/build/vfs_fonts";
pdfMake.vfs = pdfFonts.pdfMake.vfs;

import { Filesystem, FilesystemDirectory } from '@capacitor/filesystem';
// const { Filesystem, Share } = Plugins;

@Component({
  selector: 'app-offers',
  templateUrl: './offers.page.html',
  styleUrls: ['./offers.page.scss'],
})
export class OffersPage implements OnInit, OnDestroy {

  loadedList: Place[];
  private placesSub: Subscription;
  session: any;

  pdf0jb = null;

  constructor(private placesService: PlacesService,
    private file: File,
    private fileopener: FileOpener,
    private plt: Platform
    ) { }

  createPdf() {
    const pdfBlock = document.getElementById("print-wrapper");

    const options = {
      background: "white",
      height: pdfBlock.clientWidth,
      width: pdfBlock.clientHeight
    };
    domtoimage.toPng(pdfBlock, options).then((fileUrl) => {
      var doc = new JSPDF("p", "mm", "a4");
      doc.addImage(fileUrl, 'PNG', 10, 10, 240, 180);

      let docRes = doc.output();
      let buffer = new ArrayBuffer(docRes.length);
      let array = new Uint8Array(buffer);
      for (var i = 0; i < docRes.length; i++){
        array[i] = docRes.charCodeAt(i);
      }

      const directory = this.file.dataDirectory;
      const filename = "user-data.pdf";
      let options: IWriteOptions = {
        replace: true
      };

      this.file.checkFile(directory, filename).then((res) => {
        this.file.writeFile(directory, filename, buffer, options).then((res) => {
          console.log("File generated" + JSON.stringify(res));
          this.fileopener.open(this.file.dataDirectory + filename, 'application/pdf').then(() => console.log('File is exported')).catch(e => console.log(e));
      }).catch((error) => {
        console.log(JSON.stringify(error));
      });
    }).catch((error) => {
      this.file.writeFile(directory,filename,buffer).then((res)=> {
        console.log("File generated" + JSON.stringify(res));
        this.fileopener.open(this.file.dataDirectory + filename, 'application/pdf').then(() => console.log('File exported')).catch(e => console.log(e));
      }).catch((error) => {
        console.log(JSON.stringify(error));
      });
    });
  }).catch(function (error) {
    console.error(error);
  });
}


  ngOnInit() {
    this.placesSub = this.placesService.$places.subscribe(places => {
      this.loadedList = places;
      let data = localStorage.getItem('session');
      this.session = JSON.parse(data);
    });
    // this.loadedList = this.placesService.$places;
  }

  onEdit(offerId: string, itemSliding: IonItemSliding) {
    // itemSliding.close();
    console.log('Editing item:', offerId);
  }

  getDummyDate(){
    return new Date();
  }

  ngOnDestroy(){
    if(this.placesSub){
      this.placesSub.unsubscribe();
    }
  }

  download(...args: []) {
    var element = document.getElementById('table');
    var opt = {
      margin: 1,
      filename: 'output.pdf',
      image: { type: 'jpeg', quality: 0.98 },
      html2canvas: { scale: 2 },
      jsPDF: { unit: 'in', format: 'letter', orientation: 'portrait' }
    };

    // New Promise-based usage:
    html2pdf().from(element).set(opt).save();
  }

  pdfDownload(){
    const docDef = {
      pageSize: 'A4',
      pageOrientation: 'portrait',
      pageMargins:[20, 10, 20, 60],
      content: [
        {
          table: {
            body: [
              ['demo pdf column']
            ]
          }
        }
      ]
    }

    this.pdf0jb = pdfMake.createPdf(docDef);
    this.pdf0jb.download('demo.pdf');

    if(this.plt.is('cordova')){
      this.pdf0jb.getBase64(async (data) => {
        try{
          let path = 'demopdf/demoionic5pdf.pdf';
          const result = await Filesystem.writeFile({
            path,
            data: data,
            directory: FilesystemDirectory.Documents,
            recursive: true
          });
          this.fileopener.open(`${result.uri}`, 'application/pdf');
        } catch(e){
          console.log("Unable to write");
        }
      })
    }else{
    this.pdf0jb.download('demo.pdf');
  }
  }


}

import { Component, OnDestroy, OnInit } from '@angular/core';
import { IonItemSliding } from '@ionic/angular';
import { Place } from '../place.model';
import { PlacesService } from '../places.service';
import { Subscription } from 'rxjs';
import * as html2pdf from 'html2pdf.js';

@Component({
  selector: 'app-offers',
  templateUrl: './offers.page.html',
  styleUrls: ['./offers.page.scss'],
})
export class OffersPage implements OnInit, OnDestroy {

  loadedList: Place[];
  private placesSub: Subscription;
  session: any;

  constructor(private placesService: PlacesService) { }

  ngOnInit() {
    this.placesSub = this.placesService.$places.subscribe(places => {
      this.loadedList = places;
      let data = localStorage.getItem('session');
      this.session = JSON.parse(data);
    });
    // this.loadedList = this.placesService.$places;
  }

  onEdit(offerId: string, itemSliding: IonItemSliding) {
    // itemSliding.close();
    console.log('Editing item:', offerId);
  }

  getDummyDate(){
    return new Date();
  }

  ngOnDestroy(){
    if(this.placesSub){
      this.placesSub.unsubscribe();
    }
  }

  download(){
    var element = document.getElementById('table');
var opt = {
  margin:       1,
  filename:     'output.pdf',
  image:        { type: 'jpeg', quality: 0.98 },
  html2canvas:  { scale: 2 },
  jsPDF:        { unit: 'in', format: 'letter', orientation: 'portrait' }
};

// New Promise-based usage:
html2pdf().from(element).set(opt).save();
  }

}

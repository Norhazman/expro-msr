export interface Item {
  name: string;
  quantity: number;
}

import { Component, OnDestroy, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { ActionSheetController, LoadingController, ModalController, NavController } from '@ionic/angular';
import { CreateBookingComponent } from 'src/app/bookings/create-booking/create-booking.component';
import { Place } from '../../place.model';
import { PlacesService } from '../../places.service';
import { Subscription } from 'rxjs';
import { BookingsService } from 'src/app/bookings/bookings.service';
import { AuthService } from 'src/app/auth/auth.service';

@Component({
  selector: 'app-place-detail',
  templateUrl: './place-detail.page.html',
  styleUrls: ['./place-detail.page.scss'],
})
export class PlaceDetailPage implements OnInit, OnDestroy {

  place: Place;
  placesSub: Subscription;
  isBooking = false;

  constructor(private navCtrl: NavController,
              private route: ActivatedRoute,
              private placesService: PlacesService,
              private modalCtrl: ModalController,
              private asCtrl: ActionSheetController,
              private bookingService: BookingsService,
              private loadCtrl: LoadingController,
              private authService: AuthService) { }

  ngOnInit() {
    this.route.paramMap.subscribe(paramMap => {
      if (!paramMap.has('placeId')){
        // force user to navigate back to previous page
      }
      this.placesSub = this.placesService.getPlace(paramMap.get('placeId')).subscribe(place => {
        this.place = place;
        this.isBooking = place.userId !== this.authService.$userId;
      });
      // this.place = this.placesService.getPlace(paramMap.get('placeId'));
    });
  }

  onBookPlace(){
    this.asCtrl.create({
      header: 'Choose an action',
      buttons: [
        {
          text: 'Select Date',
          handler: () => {
            this.openBookingModal('select');
          }
        },
        {
          text: 'Random Date',
          handler: () => {
            this.openBookingModal('random');
          }
        },
        {
          text: 'Cancel',
          role: 'cancel'
        }
      ]
    }).then(asEl => {
      asEl.present();
    });
    //this.navCtrl.navigateBack('/places/tabs/discover');
  }

  openBookingModal(mode: 'select' | 'random'){
    console.log(mode);
    this.modalCtrl.create({
      component: CreateBookingComponent,
      componentProps: { selectedPlace: this.place, selectedMode: mode }
    }).then(modalEl => {
      modalEl.present();
      return modalEl.onDidDismiss();
    }).then(resultData => {
      // console.log(resultData.data, resultData.role);

      if(resultData.role === 'confirm'){
        // console.log('Booked');
        this.loadCtrl.create({
          message: 'Booking place...'
        }).then(loadEl => {
          loadEl.present();
          const data = resultData.data.bookingData;
        this.bookingService.addBooking(
          this.place.id,
          this.place.title,
          this.place.imageUrl,
          data.firstname,
          data.lastname,
          data.guestNumber,
          data.startDate,
          data.endDate).subscribe(() => {
            loadEl.dismiss();
          });
        });
      };
    });
  }

  ngOnDestroy(){
    if(this.placesSub){
      this.placesSub.unsubscribe();
    }
  }


}

import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from './auth/auth.service';
import { Item } from './item';
import { ItemService } from './item.service';
@Component({
  selector: 'app-root',
  templateUrl: 'app.component.html',
  styleUrls: ['app.component.scss'],
})
export class AppComponent {
  item: Item[] = [];
  error = '';
  success = '';

  constructor(private authService: AuthService,
              private router: Router,
              private itemService: ItemService) {}

  ngOnInit(){
    this.getItems();
  }

  getItems(): void {
    this.itemService.getAll().subscribe(
      (data: Item[]) => {
        this.item = data;
        this.success = 'successful retrieval of the list'
      },
      (err) => {
        console.log(err);
        this.error = err;
      }
    );
  }
  // onLogout(){
  //   this.authService.logout();
  //   this.router.navigateByUrl('/auth');
  // }

}

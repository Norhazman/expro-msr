import { Component, OnInit, OnDestroy} from '@angular/core';
import { IonItemSliding, LoadingController } from '@ionic/angular';
import { Subscription } from 'rxjs';
import { Booking } from './booking.model';
import { BookingsService } from './bookings.service';

@Component({
  selector: 'app-bookings',
  templateUrl: './bookings.page.html',
  styleUrls: ['./bookings.page.scss'],
})
export class BookingsPage implements OnInit, OnDestroy {

  loadedBookings: Booking[];
  private bookingSub: Subscription;
  constructor(private bookingService: BookingsService,
              private loadCtrl: LoadingController) { }

  ngOnInit() {
    this.bookingSub = this.bookingService.$bookings.subscribe(bookings => {
      this.loadedBookings = bookings;
    });
  }

  onCancelBooking(offerId: string, itemSliding: IonItemSliding){
    itemSliding.close();
    this.loadCtrl.create({
      message: 'Cancelling booking...'
    }).then(loadEl  => {
      loadEl.present();
      this.bookingService.cancelBooking(offerId).subscribe(() => {
        loadEl.dismiss();
      });
    });
  }

  ngOnDestroy(){
    if(this.bookingSub){
      this.bookingSub.unsubscribe();
    }
  }

}

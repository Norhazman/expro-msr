import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { map } from 'rxjs/operators';
import { Item } from './item';
@Injectable({
  providedIn: 'root'
})
export class ItemService {

  // private http = new HttpClient;
  baseUrl = 'http://localhost/api';
  constructor(private http: HttpClient) { }

    getAll() {
      return this.http.get(`${this.baseUrl}/list`).pipe(map((res:any) => {
        return res['data'];
      })
    );
  }
}

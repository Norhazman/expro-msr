import { Component, OnDestroy, OnInit, ViewChild, ElementRef } from '@angular/core';
import { IonItemSliding } from '@ionic/angular';
import { Place } from '../place.model';
import { PlacesService } from '../places.service';
import { Subscription } from 'rxjs';

// import * as html2pdf from 'html2pdf.js';

// import jsPDF from 'jspdf';
// import pdfMake from 'pdfmake/build/pdfmake';
// import pdfFonts from 'pdfmake/build/vfs_fonts';
// pdfMake.vfs = pdfFonts.pdfMake.vfs;
// import htmlToPdfmake from 'html-to-pdfmake';

@Component({
  selector: 'app-offers',
  templateUrl: './offers.page.html',
  styleUrls: ['./offers.page.scss'],
})
export class OffersPage implements OnInit, OnDestroy {

  loadedList: Place[];
  private placesSub: Subscription;
  session: any;
  // declare let html2pdf: any;

  title = 'htmltopdf';

  constructor(private placesService: PlacesService) { }

  ngOnInit() {
    this.placesSub = this.placesService.$places.subscribe(places => {
      this.loadedList = places;
      let data = localStorage.getItem('session');
      this.session = JSON.parse(data);
    });
    // this.loadedList = this.placesService.$places;
  }

  onEdit(offerId: string, itemSliding: IonItemSliding) {
    // itemSliding.close();
    console.log('Editing item:', offerId);
  }

  getDummyDate(){
    return new Date();
  }

  ngOnDestroy(){
    if(this.placesSub){
      this.placesSub.unsubscribe();
    }
  }

  loadData(){
    let data = localStorage.getItem('session');
    this.session = JSON.parse(data);
    alert(data);
  }

  // onExportClick() {
  //   const options = {
  //     filename: 'our_file.pdf',
  //     image: { type: 'jpeg' },
  //     html2canvas: {},
  //     jsPDF: { orientation: 'landscape' }
  //   };

  //   const content: Element = document.getElementById('element-to-export');

  //   html2pdf().from(content).set(options).save();
  // }


  // @ViewChild('pdfTable') pdfTable: ElementRef;
  // public downloadAsPDF() {
    // const doc = new jsPDF();
    // const pdfTable = this.pdfTable.nativeElement;
    // var html = htmlToPdfmake(pdfTable.innerHTML);
    // const documentDefinition = { content: html };
    // pdfMake.createPdf(documentDefinition).open();
  // }
}



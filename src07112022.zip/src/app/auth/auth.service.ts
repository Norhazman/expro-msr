import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  private userIsAuthenticated = true;
  private userId = 'abc123';

  constructor() { }

  get $userId() {
    return this.userId;
  }

  logIn() {
    this.userIsAuthenticated = true;
  }

  logout(){
    this.userIsAuthenticated = false;
  }

  // eslint-disable-next-line @typescript-eslint/member-ordering
  get $userIsAuthenticated() {
    return this.userIsAuthenticated;
  }
}
